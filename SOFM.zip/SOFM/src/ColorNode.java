import java.util.Random;
/*
Class: ColorNode
Date: 31, March, 2021
By: William Gullett
St#: 6426472
This class is used to store the RGB values of each node in the SOFM
 */
public class ColorNode {


    double[] RGBweights = new double[3];;

    public ColorNode(Random r){
        for(int i=0; i<3; i++){
            RGBweights[i] = r.nextDouble();
        }

    }

}
