import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
/*
Class: SOFM
Date: 31, March, 2021
This class generates a series of colored circles using a
Self-Organizing Feature Map
 */
//Used http://www.ai-junkie.com/ann/som/ to for help with algorithms,
//No code was used.
public class SOFM {


    //Adjustable parameters
    //long seed = 57430005;
    Random ran = new Random();
    double radius = 30;
    double startingLearnRate = 0.2;

    //Structure
    ColorNode[][] surface;
    double[] inputs = new double[3];

    //Image dimensions
    int x;
    int y;

    //BMU location
    int BMU_X;
    int BMU_Y;
    ColorNode BMU;



    double timeConst;

    //For printing
    BufferedImage buffer = new BufferedImage(200, 200, 	5);

    public SOFM(){
        //image dimensions
        x = 200;
        y = 200;


        //initializing
        surface = new ColorNode[x][y];
        initialize();

        //runs algorithm
        algorithm(6000);

        //Prints picture
        displayPic(surface);

        //Saves picture to FinalColors.png
        printImage(surface, "FinalColors.png");


    }

    //Prints image to assignment folder
    public void printImage(ColorNode[][] screen, String fileName){

        BufferedImage image = new BufferedImage(200, 200, 5);

        for (int i = 0; i < 200; i++) {
            for (int j = 0; j < 200; j++) {

                Color clr = new Color((float) screen[i][j].RGBweights[0], (float) screen[i][j].RGBweights[1], (float) screen[i][j].RGBweights[2]);
                image.setRGB(i, j, clr.getRGB() );

            }
        }

        File printFile = new File(fileName);
        try {
            ImageIO.write(image, "png", printFile);
        } catch(IOException e){
            System.out.println("IO Exception");
        }

    }


    //Displays picture as a buffered image
    public void displayPic(ColorNode[][] screen){

        JFrame display = new JFrame();
        for (int i = 0; i < 200; i++) {
            for (int j = 0; j < 200; j++) {

                Color clr = new Color((float) screen[i][j].RGBweights[0], (float) screen[i][j].RGBweights[1], (float) screen[i][j].RGBweights[2]);
                buffer.setRGB(i, j, clr.getRGB() );

            }
        }
        display.getContentPane().setLayout(new FlowLayout());
        display.getContentPane().add(new JLabel(new ImageIcon(buffer)));
        display.pack();
        display.setVisible(true);

    }


    //Initializes the SOFM nodes
    public void initialize(){
        for(int i=0; i<x; i++){
            for(int j=0; j<y; j++){
                surface[i][j] = new ColorNode(ran);
            }
        }
    }


    //Algorithm that creates the picture
    public void algorithm(int max){


        timeConst = timeConstant(max);
        double learningRate = startingLearnRate;
        int epoch = 1;

        while(max > 0) {

            //Generates vectors
            for(int i=0; i<3; i++){
                inputs[i] = ran.nextDouble();
            }

            //finds BMU
            findBMU();

            //Finds neighborhood radius
            double neighRadius = neighborhoodRadius(epoch, timeConst);

            for(int i=0; i<x; i++){
                for(int j=0; j<y; j++){
                    //Finds distance from one frame to the next
                    double distToNode =  distance(i, j, BMU_X, BMU_Y);

                    double width = neighRadius * neighRadius;

                   if(distToNode < width){
                       //Calculates theta
                        double theta = calculateTheta(distToNode, width);

                        for(int k=0; k<3; k++){
                            //calculates weight adjustments
                            double adjustment = (float) adjustWeights(surface[i][j].RGBweights[k], learningRate, inputs[k], theta);

                            //adjusts weights
                            surface[i][j].RGBweights[k] = adjustment;


                        }
                    }
                }
            }

            //decays learning rate
            learningRate = learningRateDecay(epoch, max);

            max--;
            epoch++;


        }


    }

    //Finds BMU by sorting through the image
    public void findBMU(){
        BMU_X = 0;
        BMU_Y = 0;
        BMU = surface[0][0];
        double bestDist = BMU(BMU);
        for(int i=0; i<x; i++){
            for(int j=0; j<y; j++){
                double dist = BMU(surface[i][j]);
                if(dist < bestDist){
                    BMU_X = i;
                    BMU_Y = j;
                    BMU = surface[i][j];
                    bestDist = dist;
                }
            }
        }
    }

    //Calculates eculidean distance
    public double BMU(ColorNode node){
        double dist = 0.0;
        for(int i=0; i<3; i++){
            dist += Math.pow((inputs[i] - node.RGBweights[i]),2);
        }
        return Math.sqrt(dist);
    }


    //Calculates time constant
    public double timeConstant(int max){
        return max/(Math.log(radius));
    }

    //Calculates neighborhood radius
    public double neighborhoodRadius(int epoch, double timeConstant){
        return radius * Math.exp(-(double)epoch/timeConstant);
    }

    //Decays learning rate
    public double learningRateDecay(int epoch, int iterationsLeft){
        return startingLearnRate * Math.exp((- (double) epoch) / iterationsLeft);
    }

    //Calculates values weights need to adjusted
    public double adjustWeights(double oldWeight, double learningRate, double vector, double theta){
        return oldWeight + (learningRate) * theta * (vector - oldWeight);
    }

    //Calculates theta
    public double calculateTheta(double distSQ, double width){
        return Math.exp(distSQ / (2*width) );
    }

    //Calculates distance between nodes
    public double distance(int x1, int y1, int x2, int y2){
        double dist = Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2);
        return Math.sqrt(dist);
    }

    public static void main(String[] args){
        SOFM s = new SOFM();
    }
}
